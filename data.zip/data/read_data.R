X = read.csv("X.csv")
y = read.csv("y.csv")
time = read.csv("time.csv")


X = data.matrix(X)
y = data.matrix(y)
time = data.matrix(time)

